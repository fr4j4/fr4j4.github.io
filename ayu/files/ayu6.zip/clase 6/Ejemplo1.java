import java.util.*; 
class Ejemplo1{
	public static void main(String[] args) {
		Random ran=new Random();
		
		int arreglo []=new int[100];
		
		String nombres[]=new String[3];

		nombres[0]="Francisco";
		nombres[1]="Jose";
		nombres[2]="Pablo";

		for (int i=0;i<arreglo.length;i++) {
			arreglo[i]=ran.nextInt(1000)+1;
		}

		int menor=arreglo[0];
		int mayor=arreglo[0];
		for (int i=0;i<arreglo.length;i++) {
			if(arreglo[i]<menor){
				menor=arreglo[i];
			}
			if(arreglo[i]>mayor){
				mayor=arreglo[i];
			}
		}

		System.out.println("Numeros generados:");
		imprimeArreglo(arreglo);

		System.out.println("El numero menor fue: "+menor);
		System.out.println("El numero mayor fue: "+mayor);

		imprimeNombres(nombres);

	}
	public static void imprimeArreglo(int [] a){
		for (int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}
	public static void imprimeNombres(String [] a){
		for (int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}
}