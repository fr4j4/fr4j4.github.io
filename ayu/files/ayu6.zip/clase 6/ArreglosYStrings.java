import java.util.*;
class ArreglosYStrings {
	public static void main(String[] args) {
		String frase="Esto es una frase de pruebas";
		String [] arreglo_de_string=new String[frase.length()];
		for (int i=0;i<arreglo_de_string.length;i++) {
			arreglo_de_string[i]=Character.toString(frase.charAt(i));
		}
		//imprime(arreglo_de_string);
		//rotar 1 unidad hacia la derecha
		//sEsto es una frase de prueba
		
		String ultimo=arreglo_de_string[arreglo_de_string.length-1];

		for (int i=arreglo_de_string.length-2;i>=0;i--) {
			arreglo_de_string[i+1]=arreglo_de_string[i];

		}
		
		arreglo_de_string[0]=ultimo;
		imprime(arreglo_de_string);


	}
	public static void imprime(String [] a){
		for (int i=0;i<a.length;i++) {
			System.out.print(a[i]);
		}
		System.out.println();
	}
}