import java.util.*;
public class RotaFrase{
        public static void main(String[]args){
                Scanner t=new Scanner(System.in);
                String frase="";
                int n=0;
                System.out.print("Ingrese una frase: ");
                frase=t.nextLine();
                n=t.nextInt();
                rotaFrase(frase,n);
        }
        public static String[] creaArr(String s){
                String[]arr=new String[s.length()];
                for(int i=0;i<s.length();i++){
                        arr[i]=Character.toString(s.charAt(i));
                }
                return arr;
        }
        public static String rotaFrase(String frase,int sentido){
                String [] A=creaArr(frase);
                String f="";
                if(sentido>0){//mayor que 0 a la derecha
                        for(int n=0;n<sentido;n++){
                                String ultimo=A[A.length-1];
                                for(int i=A.length-2;i>=0;i--){
                                                        A[i+1]=A[i];
                                                }
                                A[0]=ultimo;
                        }
                }
                else if(sentido<0){
                        sentido*=-1;
                        for(int n=0;n<sentido;n++){
                                        String primero=A[0];
                                        for(int i=1;i<A.length;i++){
                                                A[i-1]=A[i];
                                        }
                                        A[A.length-1]=primero;
                                }
                }
                imprimeArreglo(A);
                return f;
        }
        public static void imprimeArreglo(String[]A){
                for(int i=0;i<A.length;i++){
                        System.out.print(A[i]);
                }
                System.out.println();
        }
}