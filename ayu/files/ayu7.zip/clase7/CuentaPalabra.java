import java.util.*;
/*
*Programa que solicita una frase al usuario y luego ....?
 deberia imprimir en pantalla el total de palabras dentro de la frase
 suponer que las palabras estan separadas POR UN SOLO ESPACIO.
*/
class CuentaPalabra{
	public static void main(String[] args) {
		Scanner t=new Scanner(System.in);
		String palabra="";
		int numPal=0;
		System.out.println("Ingrese una frase");
		palabra=t.nextLine();
		numPal=cuentaPal2(palabra);
		System.out.println("La frase ingresada tiene "+numPal+" palabras.");
	}

	public static int cuentaPal(String f){
		String f2=f;
		int contador=1;
		int busca=f2.indexOf(" ");
		while(busca!=-1){
			contador++;
			f2=f2.substring(busca+1);
			busca=f2.indexOf(" ");
		}
		if(f.length()==0){
			contador=0;
		}
		return contador;
	}
	public static int cuentaPal2(String f){
		int contador=1;
		for(int i =0;i<f.length();i++){
			if(f.charAt(i)==' '){
				contador++;}
			}
		if(f.length()==0){
			contador=0;
		}
		return contador;
	}
}