import java.util.*;
class StringToArray {
	public static void main(String[] args) {
		Scanner t=new Scanner(System.in);
		String frase="";
		System.out.println("Ingrese una frase");
		frase=t.nextLine();
		String arr[]=convierte(frase);
		System.out.println("Arreglo de palabras");
		imprimeArreglo(arr);
	}

	public static String[] convierte(String f){
		String [] arreglo=new String[cuentaPal(f)];
		int c=0;
		String f2=f;
		while(c<arreglo.length&&f2.indexOf(" ")!=-1){
			String pal=f2.substring(0,f2.indexOf(" "));
			arreglo[c]=pal;
			f2=f2.substring(f2.indexOf(" ")+1);
			c++;
		}
		arreglo[c]=f2;
		return arreglo;
	}

	public static void imprimeArreglo(String [] a){
		for (int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}

	public static int cuentaPal(String f){
			String f2=f;
			int contador=1;
			int busca=f2.indexOf(" ");
			while(busca!=-1){
				contador++;
				f2=f2.substring(busca+1);
				busca=f2.indexOf(" ");
			}
			if(f.length()==0){
				contador=0;
			}
			return contador;
	}

}