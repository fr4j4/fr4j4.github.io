import java.util.*;
class MatrizLetrasAleatorias {
	public static void main(String[] args) {
		int n=10;
		char matriz[][]=generaMatriz(n);
		imprimeMatriz(matriz);
	}

	public static char[][] generaMatriz(int n){
		char arreglo[][]=new char[n][n];
		Random ran=new Random();

		for(int f=0;f<arreglo.length;f++){
			for(int c=0;c<arreglo[0].length;c++){
				int num=ran.nextInt(26)+65;//genera un numero entre 65 y 90
				arreglo[f][c]=(char)num;
			}
		}

		return arreglo;
	}

	public static void imprimeMatriz(char [][] M){
		for(int f=0;f<M.length;f++){
			for(int c=0;c<M[0].length;c++){
				System.out.print(M[f][c]+" ");
			}
			System.out.println();
		}
	}	
}